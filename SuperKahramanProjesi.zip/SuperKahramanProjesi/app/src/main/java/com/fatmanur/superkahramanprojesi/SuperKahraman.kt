package com.fatmanur.superkahramanprojesi

class SuperKahraman (var isim: String, var yas: Int, var meslek:String) {

}